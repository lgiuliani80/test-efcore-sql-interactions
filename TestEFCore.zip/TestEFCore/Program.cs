﻿#define USE_BEGINTRANSACTION
#define EXTRA_CONTEXT
using EFGetStarted;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System.Linq.Expressions;
using System.Reflection.Metadata;
using System.Reflection;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;

MainCode();

static void MainCode()
{
#if EXTRA_CONTEXT
    using var ctxExt = new BloggingContext();
    var strategy = ctxExt.Database.CreateExecutionStrategy();
    strategy.Execute(() => {
#endif

        using var ctx = new BloggingContext();

        var blobs = ctx.Blogs.Where(x => x.Url.Contains("a") && x.Posts.Count > 0).Include(x => x.Posts);

        Console.WriteLine($"Query: {blobs.ToQueryString()}");

        Console.WriteLine();
        Console.WriteLine("Risultati: ");

#if USE_BEGINTRANSACTION
        using (var tx = ctx.Database.BeginTransaction())
#else
    var strategy = ctx.Database.CreateExecutionStrategy();
    strategy.ExecuteInTransaction(() =>
#endif
        {
            foreach (var r in blobs)
            {
                Console.WriteLine($"{r.Url} - Entries: {r.Posts.Count}");

                foreach (var p in r.Posts)
                {
                    Console.WriteLine($"  * {p.Title} - Size = {p.ContentSize} - NumberOfReads: {p.NumberOfReads}");
                }

                r.Posts.Add(new Post
                {
                    Title = $"Titolo {Convert.ToBase64String(Guid.NewGuid().ToByteArray())}",
                    Content = $"Contenuto casuale {Guid.NewGuid()}",
                    CreatedDate = DateTimeOffset.Now,
                    //CreatedDate = DateTimeOffset.MinValue,
                    Author = "Admin"
                });
            }

            //Console.WriteLine($"Changes: {ctx.ChangeTracker.DebugView.LongView}");
            ctx.SaveChanges();

#if USE_BEGINTRANSACTION
            tx.CreateSavepoint("RP1");

            ctx.Blogs.First().Url += "/2";
            ctx.SaveChanges();

            tx.RollbackToSavepoint("RP1");
            tx.ReleaseSavepoint("RP1");

            Console.WriteLine("Do you want to commit changes [Y/N] ? ");

            switch (Console.ReadKey().KeyChar)
            {
                case 'Y':
                case 'y':
                    tx.Commit();
                    break;

                default:
                    tx.Rollback();
                    break;
            }
#endif
        }
#if !USE_BEGINTRANSACTION
    , () => false);
#endif

        ctx.Entry(ctx.Blogs.First()).Reload();

        //var listAdminPosts = ctx.Blogs.Where(x => BloggingContext.CountAdminPosts(x.BlogId) > 0).Select(x => new { x.BlogId, AdminPosts = BloggingContext.CountAdminPosts(x.BlogId), hash = BloggingContext.SHA256Unicode(x.Url) });

        var listAdminPosts = from x in ctx.Blogs let ap = BloggingContext.CountAdminPosts(x.BlogId)
                             where ap > 0
                             select new { x.BlogId, AdminPosts = ap, hash = BloggingContext.SHA256ASCII(x.Url), r = EF.Functions.Random() };

        //var listAdminPosts = (from x in ctx.Blogs
        //                     let ap = BloggingContext.CountAdminPosts(x.BlogId)
        //                     where ap > 0
        //                     select new { Entity = x, AdminPosts = ap }).ToList().Select(x => new { x.Entity.BlogId, AdminPosts = x.AdminPosts, hash = BloggingContext.SHA256ASCII(x.Entity.Url) });

        foreach (var blog in listAdminPosts)
        {
            Console.WriteLine($"- {blog.BlogId,5} : admin posts = {blog.AdminPosts} - SHA256: {BitConverter.ToString(blog.hash)}");
        }

        foreach (var blog in ctx.BlogWithPostCounts)
        {
            Console.WriteLine($"-- {blog.Url} -> {blog.PostCount} posts");
        }

        ctx.IncrementNumberOfReads();

        Console.WriteLine("POSTS WITH MORE THAN 10 READERS: ");

        foreach (var p in ctx.Posts.WithReadsGreatedThen(10))
        {
            Console.WriteLine($"- {p.Title}, reads = {p.NumberOfReads}, blogURL = {p.Blog.Url}");
        }

        Console.WriteLine("POSTS WITH MORE THAN 20 READERS: ");

        foreach (var p in ctx.MostReadPosts().OrderBy(x=> x.NumberOfReads))
        {
            Console.WriteLine($"- {p.Title}, reads = {p.NumberOfReads}, blogURL = {p.Blog.Url}");
        }

        //Expression<Func<IQueryable<Post>> exp = () => ctx.Posts.Where(x => x.NumberOfReads > 1);

        IQueryable<CommentsToPosts> dd = ctx.Comments.FromSqlInterpolated($"SELECT * FROM CommentsToPosts WHERE {typeof(CommentsToPosts).GetProperty(nameof(CommentsToPosts.Author))!.GetCustomAttribute<ColumnAttribute>()!.Name} <> 'Ciao'");

        foreach (var comment in dd) { Console.WriteLine(comment.CommentId);  }


        // ORDER BY PARAMETRICO:

        var orderByField = nameof(Post.NumberOfReads);

        // 1. Approccio 1 - semplice switch

        IQueryable<Post> result = ctx.Posts;

        switch (orderByField)
        {
            case nameof(Post.NumberOfReads):
                result = result.OrderBy(x => x.NumberOfReads); break;
            case nameof(Post.ContentSize):
                result = result.OrderBy(x => x.ContentSize); break;
            case nameof(Post.Author):
                result = result.OrderBy(x => x.Author); break;
            /* ... */
        }

        // 2. Approccio 2 - Expression Tree
        result = ctx.Posts.ParametricOrderBy(orderByField);

        foreach(Post post in result) { Console.WriteLine($"- {post.Title}");  }

#if EXTRA_CONTEXT
    });
#endif

}

public static class QueryableExtensions
{
    private static readonly MethodInfo genericOrderByMethodInfo =
        typeof(Queryable).GetMethods()
            .Where(x => x.Name == "OrderBy" && x.GetParameters().Length == 2 && x.GetParameters()[1].ParameterType.Name.Contains("Expression"))!
            .First();

    public static IQueryable<T> ParametricOrderBy<T>(this IQueryable<T> q, string orderByPropertyName)
    {
        Type fieldType = typeof(T).GetProperty(orderByPropertyName)!.PropertyType;

        var par = Expression.Parameter(typeof(T), "p");
        object expr = Expression.Lambda(Expression.Property(par, orderByPropertyName), par);

        var met = genericOrderByMethodInfo.MakeGenericMethod(typeof(T), fieldType);

        q = (IQueryable<T>)met.Invoke(q, new object[] { q, expr })!;

        return q;
    }
}